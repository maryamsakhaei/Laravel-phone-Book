@extends('master/layout')
@section('title')
    comment
@endsection
@section('content')
<body>
<div class="container">
    <h2 class="text-center">Contac Form</h2>
	<div class="row left-content-center">
		<div class="col-12 col-md-8 col-lg-6 pb-5">
                    <form action="{{url('Update')}}" method="post" enctype="multipart/form-data">
                        @csrf
                        <div class="card border-primary rounded-0">
                            <div class="card-header p-0">
                                <div class="bg-info text-white text-center py-2">
                                    <h3> Contact</h3>
                                    <p class="m-0"></p>
                                </div>
                            </div>
                            <div class="card-body p-3">

                                <!--Body-->
                                @foreach($contactslist as $contactslist)
                                <div class="form-group">
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="fa fa-user text-info"></i></div>
                                        </div>
                                        <input type="text" class="form-control" id="nombre" name="name" value="{{$contactslist-> name}}" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="fa fa-phone text-info" style="font-size:24px"></i></div>
                                        </div>
                                        <input type="number" class="form-control" id="nombre" name="number" value="{{$contactslist-> number}}" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="fa fa-comment text-info"></i></div>
                                        </div>
                                        <label for="grouptype">Group Type: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{$contactslist-> grouptype}} </label><br>
                                            <select name="grouptype" id="grouptype" value="{{$contactslist-> grouptype}}">
                                            <option value="0">...</option>
                                            <option value="1">Family</option>
                                            <option value="2">Freind</option>
                                            <option value="3">colleague</option>
                                            <option value="4">partner</option>
                                            </select>
                                    </div>
                                </div>
                                @endforeach
                                <div class="text-center">
                                    <input type="submit" value="Update" class="btn btn-info btn-block rounded-0 py-2">
                                </div>
                            </div>

                        </div>
                    </form>
                    @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif
                    <!--Form with header-->
                   
                </div>

	</div>
</div>
@endsection