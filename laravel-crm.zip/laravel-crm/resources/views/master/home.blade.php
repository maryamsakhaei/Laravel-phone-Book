@extends('layout')
@section('title')
    CRM
@endsection
