@include('master/header')
@yield('content')
@include('master/footer')
