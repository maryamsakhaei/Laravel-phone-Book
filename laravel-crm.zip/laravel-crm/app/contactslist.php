<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class contactslist extends Model
{
    use Notifiable;
    protected $table='contactslist';
    public $timestamps = false;
    protected $fillable = [
    'name','number', 'grouptype'
    ];
}
