<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Validator;
use Redirect;
use Input;
use Hash;
use App\contactslist;

class ContactController extends Controller
{
    public function Contact(){
        return view('Contacts');
    }
    //==================stotre====================================//
    public function Store(Request $req){
        // if($_POST['number']!=null){

        // }
        $validatedData = $req->validate([
            'number'=>'require',
            'name'=>'require',
            ]);
            // 'name' => ['required', 'string', 'max:255'],
            // 'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            // 'password' => ['required', 'string', 'min:8', 'confirmed'],
            // return contactslist::create([
            //     'name' => $data['name'],
            //     'email' => $data['email'],
            //     'password' => Hash::make($data['password']),
            // ]);
            
        //     $contactslist=new contactslist($req->all());
        //     if($contactslist->save()){
        //         $url=url('show');
        //         return redirect($url);
                //    }
        contactslist::create(['name' => $req->name,'number' => $req->number, 'grouptype' => $req->grouptype]);
        $contactslist = DB::select('select * from contactslist');
        return view('show',['name'=>$req->name,'number'=>$req->number,'grouptype'=>$req->grouptype,'contactdata'=>end($contactslist)]);
       
        }
//==================show====================================//   
public function Show($id){
    $contactslist=contactslist::find($id);
    $contactslist=contactslist::query()->where('id','=',$id)->get();
    //dd( $contactslist);    
    return view ('show')->with('contactslist',$contactslist);
 }     
 //==================Edit====================================//   
public function Edit($id){
    $contactslist=contactslist::find($id);
    $contactslist=contactslist::query()->where('id','=',$id)->get();
    //dd( $contactslist);    
    return view ('edit')->with('contactslist',$contactslist);
 } 
  //==================Update====================================//   
public function Update(Request $req){
    DB::table('contactslist')  
            
            ->update(['name' => $req->name,'number' => $req->number,'grouptype' => $req->grouptype]);
           // echo "ok";
           $contactslist = DB::select('select * from contactslist');
            $url=url('edit').'/'.$contactslist->$id;
            return redirect($url);
 } 
}
