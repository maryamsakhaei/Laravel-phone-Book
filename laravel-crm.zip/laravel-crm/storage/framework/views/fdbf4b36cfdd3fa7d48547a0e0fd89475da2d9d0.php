<?php $__env->startSection('title'); ?>
    comment
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<body>
<div class="container">
    <h2 class="text-center">Contac Form</h2>
	<div class="row left-content-center">
		<div class="col-12 col-md-8 col-lg-6 pb-5">
                    <form > 
                        <div class="card border-primary rounded-0">
                            <div class="card-header p-0">
                                <div class="bg-info text-white text-center py-2">
                                    <h3> Contact</h3>
                                    <p class="m-0"></p>
                                </div>
                            </div>
                            <div class="card-body p-3">

                                <!--Body-->
                                
                                <div class="form-group">
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="fa fa-user text-info"></i></div>
                                        </div>
                                       
                                        <input type="text" class="form-control" value="<?php echo e($name); ?>" >
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="fa fa-phone text-info" style="font-size:24px"></i></div>
                                        </div>
                                        <input type="text" class="form-control" value="<?php echo e($number); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="input-group mb-2">
                                        <div class="input-group-prepend">
                                            <div class="input-group-text"><i class="fa fa-phone text-info" style="font-size:24px"></i></div>
                                        </div>
                                        <input type="text" class="form-control" value="<?php echo e($grouptype); ?>">

                                    </div>
                                </div>

                                
                               
                            </div>

                        </div>
                    </form>
                 
                    <!--Form with header-->
                   
                </div>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master/layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>